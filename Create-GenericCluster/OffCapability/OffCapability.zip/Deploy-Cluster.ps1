## Declare parameters
$armTemplate = ".\Cluster-ExternalRoot.json"
$currentExecutionPath = "D:\Code\FabricMonkey\FabricScripts\Create-GenericCluster\OffCapability"

## Fixed parameters
$subscriptionId = "13ad2c84-84fa-4798-ad71-e70c07af873f"
$azureRegion = "westus"
$localCertificatePath = "D:\Certificates\"
$machineAdminUser = "Christian"
$machineAdminPass = "nZ549Ux2MnW6srTvOZsq"
$clusterVersion = "7.1.409.9590"

## Set environment
Try {
  Select-AzSubscription -SubscriptionId $subscriptionId -ErrorAction Stop
} Catch {
    Login-AzAccount
    Set-AzContext -SubscriptionId $subscriptionId
}
cd $currentExecutionPath
Enable-AzureRmAlias

## Generate unique id strings
$deploymentName = "chrpap" + (Get-Date).ToString("ddHHmm")

# Define dynamic parameters
$certificateName = $deploymentName + "cert"
$resourceGroup = $deploymentName + "group"
$fileShareStorageName = $deploymentName + "fileshare"
$scriptStorageName = $deploymentName + "script"
$keyVaultName = $deploymentName + "keyvault"
$serviceFabricClusterName = $deploymentName + "servicefabric"
$serviceFabricClusterDns = $serviceFabricClusterName + "." + $azureRegion + ".cloudapp.azure.com"

## Deploy Azure Key Vault
New-AzResourceGroup -Name $resourceGroup -Location $azureRegion -Force 
New-AzKeyVault -VaultName $keyVaultName -ResourceGroupName $resourceGroup -Location $azureRegion -EnabledForDeployment
Import-Module ".\..\ServiceFabricRPHelpers\ServiceFabricRPHelpers.psm1"
New-Item -ItemType Directory -Path $localCertificatePath -ErrorAction Ignore
$clusterCertificate = Invoke-AddCertToKeyVaultAsSecret -SubscriptionId $subscriptionId -ResourceGroupName $resourceGroup -Location $azureRegion -VaultName $keyVaultName -CertificateName $certificateName -CreateSelfSignedCertificate -DnsName $serviceFabricClusterDns -OutputPath $localCertificatePath -Password $machineAdminPass
$clusterCertificate.CertificateThumbprint
$clusterCertificate.SourceVault
$clusterCertificate.CertificateURL

## Create storage account
$containerName = "extensionscripts"
$extensionMountScriptFileName = "Mount-ManagedDisk.ps1"
$extensionMountScriptFilePath = ".\Mount-ManagedDisk.ps1"
$scriptStorageAccount = New-AzStorageAccount -ResourceGroupName $resourceGroup -Name $scriptStorageName -Location $azureRegion -SkuName Standard_LRS -Kind StorageV2
$scriptStorageAccountContext = $scriptStorageAccount.Context
New-AzStorageContainer -Name $containerName -Context $scriptStorageAccountContext -Permission blob
$uploadedBlobContent1 = Set-AzStorageBlobContent -File $extensionMountScriptFileName -Container $containerName -Blob $extensionMountScriptFilePath -Context $scriptStorageAccountContext 
$extensionMountScriptFileUri = $uploadedBlobContent1.ICloudBlob.uri.AbsoluteUri

## Deploy Azure Service Fabric Cluster
$armParameter = @{}
$armParameter.Add("deploymentId", $deploymentName)
$armParameter.Add("clusterVersion", $clusterVersion)
$armParameter.Add("computeLocation", $azureRegion)
$armParameter.Add("clusterName", $serviceFabricClusterName)
$armParameter.Add("adminPassword", $machineAdminPass)
$armParameter.Add("sourceVaultValue", $clusterCertificate.SourceVault)
$armParameter.Add("certificateUrlValue", $clusterCertificate.CertificateURL)
$armParameter.Add("certificateThumbprint", $clusterCertificate.CertificateThumbprint)
$armParameter.Add("extensionMountScriptFileUri", $extensionMountScriptFileUri)

Test-AzResourceGroupDeployment -ResourceGroupName $resourceGroup -TemplateFile $armTemplate -TemplateParameterObject $armParameter -Verbose -ErrorAction Stop

New-AzResourceGroupDeployment -ResourceGroupName $resourceGroup -TemplateFile $armTemplate -TemplateParameterObject $armParameter -Verbose -Mode Incremental

## Import certificate in local store
$certificateFile = $localCertificatePath + $certificateName + ".pfx"
$certificatePassword = ConvertTo-SecureString $machineAdminPass -AsPlainText -Force
Import-PfxCertificate -Exportable -CertStoreLocation Cert:\CurrentUser\My -FilePath $certificateFile -Password $certificatePassword
Import-PfxCertificate -Exportable -CertStoreLocation Cert:\CurrentUser\TrustedPeople -FilePath $certificateFile -Password $certificatePassword

## Output
$output = "Deployment Name: $deploymentName; Thumbprint: " + $clusterCertificate.CertificateThumbprint
Write-Host $output
$output | Out-File -FilePath "C:\Temp\$deploymentName.txt"

$ConnectArgs = @{  
        ConnectionEndpoint = 'chrpap200922servicefabric.westus.cloudapp.azure.com:19000';  
        X509Credential = $True;  
        StoreLocation = 'CurrentUser';  
        StoreName = "MY";  
        ServerCommonName = "chrpap200922servicefabric.westus.cloudapp.azure.com";  
        FindType = 'FindByThumbprint';  
        FindValue = "6A5DC6E2D333894169EE6DA2196FF4E6E9C257B1"   
    }
Connect-ServiceFabricCluster @ConnectArgs